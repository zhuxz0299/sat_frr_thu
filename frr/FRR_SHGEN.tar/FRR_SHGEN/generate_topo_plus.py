import yaml
import math

# 初始化 Containerlab 的基础结构
lab = {
    "name": "sat-network",
    "mgmt": {
        "network": "my_network",
        "ipv4-subnet": "166.166.0.0/16"
    },
    "topology": {
        "nodes": {},
        "links": []
    }
}

# 自定义 Dumper，确保多行列表格式正确
class CustomDumper(yaml.Dumper):
    def increase_indent(self, flow=False, indentless=False):
        return super(CustomDumper, self).increase_indent(flow, False)

# 节点类型的通用逻辑
def create_nodes(node_type, count, ip_base, subnet):
    """
    创建指定类型的节点并添加到拓扑中。
    :param node_type: 节点类型前缀 (如 "LEO", "MEO", "GROUND")
    :param count: 节点数量
    :param ip_base: IP 地址基础部分 (如 "192.168" 或 "192.167")
    :param subnet: 子网掩码 (如 "/16" 或 "/24")
    """
    for i in range(1, count + 1):
        node_name = f"{node_type}{i}"
        if node_type == "LEO":
            a = i % 255 + 1
            b = math.floor(i / 255) + 1
            ip = f"{ip_base}.{b}.{a}{subnet}"
        else:
            ip = f"{ip_base}.1.{i}{subnet}"

        lab["topology"]["nodes"][node_name] = {
            "kind": "linux",
            "image": "frrouting/frr:v8.2.2",
            "binds": [f"sat_output/{node_name}/daemons:/etc/frr/daemons"],
            "exec": [f"ip address add {ip} dev e0"]
        }

# 创建节点
create_nodes("LEO", 60, "192.168", "/16")
create_nodes("MEO", 3, "192.167", "/24")
create_nodes("GROUND", 1, "192.166", "/24")

# 创建链接
def create_links():
    """
    创建 LEO 与 MEO 以及 GROUND 与 MEO 的链接。
    """
    # 每个 MEO 与每个 LEO 相连
    for meo_id in range(1, num_meo + 1):
        for leo_id in range(1, num_leo + 1):
            lab["topology"]["links"].append({
                "endpoints": [f"MEO{meo_id}:e1-{leo_id}", f"LEO{leo_id}:e{meo_id}-1"]
            })

    # GROUND 与每个 MEO 相连
    for meo_id in range(1, num_meo + 1):
        lab["topology"]["links"].append({
            "endpoints": [f"GROUND1:e1-{meo_id}", f"MEO{meo_id}:e{num_leo + 1}-1"]
        })

# 创建链接
num_leo = 60
num_meo = 3
num_ground = 1
create_links()

# 将配置保存为 YAML 文件
with open("sat-network.clab.yaml", "w") as file:
    yaml.dump(lab, file, Dumper=CustomDumper, default_flow_style=False, sort_keys=False)

print("sat-network.clab.yaml 已生成！")