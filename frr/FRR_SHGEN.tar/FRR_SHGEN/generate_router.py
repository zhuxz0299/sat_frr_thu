import os
import shutil


def create_and_copy(source_path, output_dir, prefix, count):
    """
    创建目标文件夹并复制文件到目标文件夹。

    :param source_path: 源文件路径
    :param output_dir: 输出基目录
    :param prefix: 文件夹前缀名 (如 "LEO", "MEO", "GROUND")
    :param count: 创建的文件夹数量
    """
    for i in range(1, count + 1):
        # 创建目标文件夹路径
        target_dir = os.path.join(output_dir, f"{prefix}{i}")
        os.makedirs(target_dir, exist_ok=True)
        try:
            # 复制文件到目标文件夹
            target_file = os.path.join(target_dir, "daemons")
            shutil.copy(source_path, target_file)
            print(f"成功复制到 {target_dir}")
        except Exception as e:
            print(f"错误: 无法复制到 {target_dir} - {e}")


# 原始 daemons 文件所在的路径
source_daemons_path = "./router/daemons"

# 检查原始 daemons 文件是否存在
if not os.path.exists(source_daemons_path):
    print(f"错误: 找不到文件 {source_daemons_path}")
    exit(1)

# 输出的目标文件夹路径
output_base_dir = "./sat_output"

# 创建根输出文件夹
os.makedirs(output_base_dir, exist_ok=True)

# 配置数量
num_leo = 60  # 低轨道卫星 (LEO)
num_meo = 3  # 中轨道卫星 (MEO)
num_ground = 1  # 地面站 (GROUND)

# 调用函数处理不同类型的卫星和地面站
create_and_copy(source_daemons_path, output_base_dir, "LEO", num_leo)
create_and_copy(source_daemons_path, output_base_dir, "MEO", num_meo)
create_and_copy(source_daemons_path, output_base_dir, "GROUND", num_ground)

print("所有文件夹生成并复制完成。")
